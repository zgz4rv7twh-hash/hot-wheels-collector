# Hot Wheels Collector – iPhone PWA

## Enthalten
- Dunkles Sammler-Interface
- Garage, Alle-Autos- und Fehlende-Ansicht
- Suche nach Name, Serie, Jahr und Nummer
- Lokale Speicherung des Sammlerstatus im Browser
- Fotoaufnahme über iPhone-Kamera-Dateiauswahl
- Manuelle Barcode-Eingabe
- PWA-Manifest, Service Worker und App-Icons

## Auf dem iPhone installieren
1. Diese Dateien auf einen HTTPS-Webhost hochladen (z. B. eine eigene Website oder einen statischen Hosting-Dienst).
2. Die veröffentlichte Adresse in **Safari** auf dem iPhone öffnen.
3. Auf **Teilen** tippen.
4. **Zum Home-Bildschirm** auswählen.
5. Den Namen „Hot Wheels Collector“ bestätigen und **Hinzufügen** tippen.

Eine PWA muss über HTTPS ausgeliefert werden (localhost ist die Ausnahme). Eine direkt installierbare iOS-IPA-Datei ist nicht enthalten; diese benötigt Apples Signierung und einen entsprechenden Veröffentlichungs-/Installationsweg.

## Grenzen dieser Version
Die enthaltenen Fahrzeuge sind Beispieldatensätze und keine vollständige, lizenzierte Hot-Wheels-Datenbank. Kamera-Fotoaufnahme und Barcode-Eingabe sind vorhanden, aber es gibt noch keine automatische Barcode-/Bild-Erkennung oder externe Datenbankabfrage. Der Sammlerstatus wird lokal im Browser gespeichert und noch nicht zwischen Geräten synchronisiert.
